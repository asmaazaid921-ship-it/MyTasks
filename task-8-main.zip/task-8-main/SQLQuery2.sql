--Create a table named "Employees" with columns for ID (integer), Name (varchar), and Salary (decimal).


--Add a primary key constraint to the "Employees" table for the "ID" column.
--Add a unique constraint to the "Name" column in the "Employees" table.

CREATE TABLE Employees (
id int PRIMARY KEY  ,
name varchar(20)   unique ,
 Salary decimal( 5,3),
)
  --Add a new column named "Department" to the "Employees" table with data type varchar(50).

  alter table  Employees 

  add Department varchar(50)


  --Remove the "Salary" column from the "Employees" table.

  

   ALTER table  Employees 

   drop COLUMN Salary

   --Rename the "Department" column in the "Employees" table to "DeptName".


   EXECUTE sp_rename 'Employees.Department' ,'DeptName','column'


   --Create a new table called "Projects" with columns for ProjectID (integer) and ProjectName (varchar).

   CREATE TABLE Projects (
 pro_id int   ,
  pro_name varchar(20),

)


--Create a table named "Customers" with columns for CustomerID (integer), FirstName (varchar), LastName (varchar), and Email (varchar), and Status (varchar).



--Add a unique constraint to the combination of "FirstName" and "LastName" columns in the "Customers" table.


CREATE TABLE  Customers(
cus_id int   ,
f_name varchar(20)  unique ,
l_name varchar(20)  unique ,
statee char(4),
Email varchar(30),
)


--Create a table named "Orders" with columns for OrderID (integer), CustomerID (integer), OrderDate (datetime), and TotalAmount (decimal).
--Add a check constraint to the "TotalAmount" column in the "Orders" table to ensure that it is greater than zero.

CREATE TABLE Orders (
ord_id int   ,
cus_id  int   ,
OrderDate datetime,
TotalAmount decimal check (TotalAmount >0)
)
  