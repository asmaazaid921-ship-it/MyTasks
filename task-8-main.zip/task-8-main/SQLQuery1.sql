CREATE DATABASE Task7

USE Task7

GO 

CREATE SCHEMA movement ;

GO 

CREATE TABLE  movement.actor(
actid int PRIMARY KEY  ,
actf_name varchar(20),
actl_name varchar(20),
actgender char(1),
)

CREATE TABLE  movement.director(
dirid int PRIMARY KEY  ,
dirf_name varchar(20),
dirl_name varchar(20),

)
CREATE TABLE  movement.movie
(
mov_id int PRIMARY KEY  ,
mov_title varchar(20),
mov_year int,
mov_time int,
mov_long int,
mov_dt_rel datetime2,
mov_dt_countre char(2),



)
CREATE TABLE  movement.movie_direction
(
mov_id int,
dirid int,

primary key (mov_id , dirid),
foreign key ((mov_id) REFERENCES movement.movie(ID)),
foreign key ((dirid) REFERENCES movement.direction(ID)),

)

CREATE TABLE  movement.movie_cast
(
mov_id int REFERENCES movement.movie(ID) ,
actid int REFERENCES movement.actor(ID),
role char(20),


)
CREATE TABLE  movement.reviewer
(
rev_id int PRIMARY KEY  ,
rev_name char(20),


)
CREATE TABLE  movement.genres
(
gen_id int PRIMARY KEY  ,
gen_title char(20),


)
CREATE TABLE  movement.movie_genres
(
mov_id int,

gen_id int,

primary key (mov_id ,gen_id ),
foreign key ((mov_id) REFERENCES movement.movie(ID)),
foreign key ((gen_id) REFERENCES movement.genres(ID)),



)


CREATE TABLE  movement.rating
(
mov_id int,

rev_id int,
rev_stars int,
num_0_ratings int,

)